﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using BrightIdeasSoftware;

namespace AnimatedApplication
{
    public partial class Form1 : Form
    {
        public Form1() {
            InitializeComponent();
        }

        #region Event handlers

        private void Form1_Load(object sender, EventArgs e) {
            this.RunSpinnerAnimation();
            this.InitializeDataGridView();
        }

        private void button1_Click(object sender, EventArgs e) {
            this.RunBorderAnimation();
            this.RunAnimationOnPauseButton();
        }

        private void button2_Click(object sender, EventArgs e) {
            this.RunAnimationOnPauseButton();
            this.RunSpinnerAnimation();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.RunAnimationOnPauseButton();
            this.RunLoveheartAnimation();
        }

        private void button4_Click(object sender, EventArgs e) {
            this.RunAnimationOnPauseButton();
            this.RunShapeAnimation();
        }

        private void buttonPause_Click(object sender, EventArgs e) {
            this.animation.Paused = !this.animation.Paused;
            this.UpdateUIState();
        }

        void animation_Started(object sender, StartAnimationEventArgs e) {
            this.UpdateUIState();
        }

        void animation_Stopped(object sender, StopAnimationEventArgs e) {
            this.UpdateUIState();
        }

        private void UpdateUIState() {
            if (this.InvokeRequired) {
                this.Invoke((MethodInvoker)delegate { this.UpdateUIState(); });
                return;
            }
            this.buttonPause.Enabled = this.animation.Running;
            if (this.animation.Running && this.animation.Paused)
                this.buttonPause.Text = "Un&pause";
            else
                this.buttonPause.Text = "&Pause";
        }

        #endregion

        #region Animations

        private Animation CreateAnimation() {
            if (this.animation != null) {
                this.animation.Stop();
                this.animation.Started -= new EventHandler<StartAnimationEventArgs>(animation_Started);
                this.animation.Stopped -= new EventHandler<StopAnimationEventArgs>(animation_Stopped);
            }

            if (this.tabControl1.SelectedIndex == 1)
                this.controlWithAnimation = new AnimationAdapter(this.dataGridView1);
            else
                this.controlWithAnimation = new AnimationAdapter(this.userControl11);

            this.animation = this.controlWithAnimation.Animation;
            this.animation.Started += new EventHandler<StartAnimationEventArgs>(animation_Started);
            this.animation.Stopped += new EventHandler<StopAnimationEventArgs>(animation_Stopped);

            return this.animation;
        }
        
        private void RunBorderAnimation() {
            this.animation = this.CreateAnimation();

            ShapeSprite shape = new ShapeSprite();
            shape.PenWidth = 3.0f;
            shape.Opacity = 0.8f;
            shape.Size = new Size(200, 300);
            shape.Add(0, 2000, Effects.Bounds(Locators.At(200, 300, 100, 200), Locators.AnimationBounds(-50, -50)));
            shape.Add(2000, 1500, Effects.Bounds(Locators.AnimationBounds(-150, -150)));
            shape.Add(3500, 1500, Effects.Bounds(Locators.At(200, 300, 100, 200)));
            this.animation.Add(0, shape);

            Sprite sprite = new ImageSprite(Properties.Resources.redloveheart);
            sprite.Add(0, 500, Effects.Fade(0.0f, 0.8f));
            sprite.Add(0, 5000, Effects.Walk(Locators.AnimationBounds(-100, -100), WalkDirection.Anticlockwise));
            sprite.Add(2200, 2800, Effects.Rotate(0, 680));
            sprite.Add(4500, 500, Effects.Fade(0.8f, 0.0f));
            this.animation.Add(0, sprite);

            Sprite sprite2 = new ImageSprite(Properties.Resources.goldstar3);
            sprite2.Add(0, 5000, Effects.Walk(new SpriteBoundsLocator(shape), Corner.BottomRight, WalkDirection.Clockwise));
            sprite2.Add(0, 5000, Effects.Rotate(0, -360 * 4));
            this.animation.Add(0, sprite2);

            this.animation.Start();
        }

        private void RunSpinnerAnimation() {
            this.animation = this.CreateAnimation();

            Sprite image = new ImageSprite(Properties.Resources.goldstar3);
            image.Add(0, 500, Effects.Move(Corner.BottomCenter, Corner.MiddleCenter));
            image.Add(0, 500, Effects.Rotate(0, 180));
            image.Add(500, 1500, Effects.Rotate(180, 720));
            image.Add(1000, 1000, Effects.Scale(1.0f, 4.0f));
            image.Add(1000, 1000, Effects.Goto(Corner.MiddleCenter));
            image.Add(1000, 1000, Effects.Fade(1.0f, 0.0f));
            this.animation.Add(0, image);

            Sprite text = new TextSprite("Animated!", new Font("Tahoma", 32), Color.Blue, Color.AliceBlue, Color.Red, 3.0f);
            text.Opacity = 0.0f;
            text.FixedLocation = Locators.SpriteAligned(Corner.MiddleCenter);
            text.Add(900, 600, Effects.Fade(0.0f, 1.0f));
            text.Add(1000, 800, Effects.Rotate(180, 1440));
            text.Add(2000, 500, Effects.Scale(1.0f, 0.5f));
            text.Add(3500, 1000, Effects.Scale(0.5f, 4.0f));
            text.Add(3500, 1000, Effects.Fade(1.0f, 0.0f));
            this.animation.Add(0, text);

            TextSprite text2 = new TextSprite("Ticker Board Effect", new Font("Tahoma", 24), Color.AliceBlue);
            text2.BackColor = Color.DarkSlateGray;
            text2.FixedLocation = Locators.SpriteAligned(Corner.TopCenter, new Point(20, 20));
            text2.Add(0, 300, Effects.Fade(0.0f, 1.0f));
            text2.Add(900, 2700, Effects.TickerBoard("Interesting -- but useless"));
            this.animation.Add(0, text2);

            this.animation.Start();
        }

        /// <summary>
        /// Put a moving spinning star over the Pause button, just to show we can :)
        /// </summary>
        private void RunAnimationOnPauseButton() {
            AnimationAdapter pauseButtonAnimationAdaptor = new AnimationAdapter(this.buttonPause);
            Animation pauseButtonAnimation = pauseButtonAnimationAdaptor.Animation;

            Sprite imagesprite = new ImageSprite(Properties.Resources.smallGoldstar);
            imagesprite.Add(0, 3000, Effects.Move(Corner.MiddleLeft, new Point(-20, 0),
                Corner.MiddleRight, new Point(20, 0)));
            imagesprite.Add(0, 3000, Effects.Rotate(0, 680));
            pauseButtonAnimation.Add(0, imagesprite);

            pauseButtonAnimation.Start();
        }

        private void RunLoveheartAnimation() {
            this.animation = this.CreateAnimation();
            this.animation.Repeat = Repeat.Pause;

            Sprite imagesprite = new ImageSprite(Properties.Resources.heart);
            imagesprite.Opacity = 0.0f;
            imagesprite.FixedLocation = Locators.SpriteAligned(Corner.MiddleCenter, new Point(-5, 10));
            imagesprite.Add(0, 1500, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(2500, imagesprite);

            Sprite letterP1 = new TextSprite("P", new Font("Digiface", 48), Color.Black);
            letterP1.Add(0, 1500, Effects.Move(Corner.TopLeft, Corner.MiddleCenter, new Point(-20, -30)));
            this.animation.Add(0, letterP1);

            Sprite letterP2 = new TextSprite("P", new Font("Digiface", 48), Color.Black);
            letterP2.Add(0, 1500, Effects.Move(Corner.TopRight, Corner.MiddleCenter, new Point(20, -30)));
            this.animation.Add(0, letterP2);

            Sprite letterN = new TextSprite("N", new Font("Curlz MT", 48), Color.Black);
            letterN.Opacity = 0.0f;
            letterN.Add(0, 500, Effects.Fade(0.0f, 1.0f));
            letterN.Add(0, 1500, Effects.Move(Corner.BottomLeft, Corner.MiddleCenter, new Point(-20, 30)));
            this.animation.Add(1000, letterN);

            Sprite letterS = new TextSprite("S", new Font("Curlz MT", 48), Color.Black);
            letterS.Opacity = 0.0f;
            letterS.Add(0, 500, Effects.Fade(0.0f, 1.0f));
            letterS.Add(0, 1500, Effects.Move(Corner.BottomRight, Corner.MiddleCenter, new Point(20, 30)));
            letterS.Add(4000, 1000, Effects.Fade(1.0f, 0.0f));
            this.animation.Add(1000, letterS);

            Audio sound = new Audio("kiss.wav");
            //Audio sound = Audio.FromResource("slap.wav");
            this.animation.Add(2500, sound);

            Sprite photo1 = new ImageSprite(Properties.Resources.NicolaBridal);
            photo1.Opacity = 0.0f;
            photo1.Add(Effects.Goto(Corner.MiddleCenter));
            photo1.Add(0, 1000, Effects.Move(Corner.TopLeft));
            photo1.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(3500, photo1);

            Sprite letterP3 = new TextSprite("P!", new Font("Curlz MT", 48), Color.Black);
            letterP3.Opacity = 0.0f;
            letterP3.Add(Effects.Goto(Corner.MiddleCenter, new Point(20, 30)));
            letterP3.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(5000, letterP3);

            Sprite photo2 = new ImageSprite(Properties.Resources.Joshua);
            photo2.Opacity = 0.0f;
            photo2.Add(Effects.Goto(Corner.MiddleCenter));
            photo2.Add(0, 1000, Effects.Move(Corner.TopRight));
            photo2.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(6000, photo2);

            Sprite photo3 = new ImageSprite(Properties.Resources.Drew);
            photo3.Opacity = 0.0f;
            photo3.Add(Effects.Goto(Corner.MiddleCenter));
            photo3.Add(0, 1000, Effects.Move(Corner.BottomRight));
            photo3.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(7000, photo3);

            Sprite photo4 = new ImageSprite(Properties.Resources.Isa);
            photo4.Opacity = 0.0f;
            photo4.Add(Effects.Goto(Corner.MiddleCenter));
            photo4.Add(0, 1000, Effects.Move(Corner.BottomLeft));
            photo4.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(8000, photo4);


            string msg = "This animation remains visible when it finishes. To remove it, play a different animation.";
            TextSprite msgSprite = new TextSprite(msg, new Font("Arial", 10), Color.DarkSlateBlue);
            msgSprite.MaximumTextWidth = 300;
            msgSprite.Wrap = true;
            msgSprite.BackColor = Color.WhiteSmoke;
            msgSprite.FixedLocation = Locators.SpriteAligned(Corner.BottomCenter);
            msgSprite.Opacity = 0.0f;
            msgSprite.Add(0, 1000, Effects.Fade(0.0f, 1.0f));
            this.animation.Add(10000, msgSprite);

            this.animation.Start();
        }

        private void RunShapeAnimation() {
            this.animation = this.CreateAnimation();

            Sprite sprite = ShapeSprite.Circle(3.0f, Color.Red);
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Move(0.1f, -0.1f, 0.1f, 1.2f));
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(0, sprite);

            sprite = ShapeSprite.Oval(8.0f, Color.DeepPink, Color.Pink);
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Move(0.2f, -0.1f, 0.2f, 1.2f));
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(300, sprite);

            sprite = ShapeSprite.FilledRectangle(Color.PeachPuff);
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Move(0.3f, -0.1f, 0.3f, 1.2f));
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(600, sprite);

            sprite = ShapeSprite.RoundedRectangle(8.0f, Color.DarkGoldenrod, Color.PaleGoldenrod);
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Move(0.7f, -0.1f, 0.7f, 1.2f));
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(950, sprite);

            sprite = ShapeSprite.Square(3.0f, Color.Blue);
            sprite.Add(0, 3000, Effects.Move(0.8f, -0.1f, 0.8f, 1.2f));
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(1150, sprite);

            sprite = ShapeSprite.Triangle(1.0f, Color.Black, Color.Orchid);
            sprite.Add(0, 3000, Effects.Move(0.9f, -0.1f, 0.9f, 1.2f));
            sprite.Size = new Size(100, 150);
            sprite.Add(0, 3000, Effects.Rotate(0, 680));
            this.animation.Add(1350, sprite);

            this.animation.Start();
        }

        #endregion

        #region Data view handling

        private void InitializeDataGridView() {
            DataSet ds = LoadDatasetFromXml("Persons.xml");

            if (ds.Tables.Count > 0) {
                this.dataGridView1.DataSource = ds;
                this.dataGridView1.DataMember = "Person";
            }
        }

        private DataSet LoadDatasetFromXml(string fileName) {
            DataSet ds = new DataSet();
            FileStream fs = null;

            try {
                fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                using (StreamReader reader = new StreamReader(fs)) {
                    ds.ReadXml(reader);
                }
            } catch (Exception e) {
                MessageBox.Show(e.ToString());
            } finally {
                if (fs != null)
                    fs.Close();
            }

            return ds;
        }

        #endregion

        #region Private variables

        AnimationAdapter controlWithAnimation;
        Animation animation;

        #endregion
    }
}
