﻿using System;
using System.Drawing;
using System.Diagnostics;

using NUnit.Framework;

using BrightIdeasSoftware;

namespace BrightIdeasSoftware.AnimationTests
{
    [TestFixture]
    public class EffectTests
    {
        [SetUp]
        public void Setup() {
            NUnit.Framework.GlobalSettings.DefaultFloatingPointTolerance = 0.0000001;        
        }

        [Test]
        public void TestMoveEffect() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);

            IPointLocator pl1 = Locators.At(100, 200);
            IPointLocator pl2 = Locators.At(100, 300);

            IEffect effect = new MoveEffect(pl1, pl2);
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);

            effect.Apply(0.5f);
            Assert.AreEqual(new Point(100, 250), sprite.Location);

            effect.Apply(1.0f);
            Assert.AreEqual(new Point(100, 300), sprite.Location);
        }

        [Test]
        public void TestMoveEffect_ImpliedStartLocation() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);

            IPointLocator pl1 = Locators.At(100, 200);

            IEffect effect = new MoveEffect(pl1);
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(new Point(10, 20), sprite.Location);

            effect.Apply(0.5f);
            Assert.AreEqual(new Point(55, 110), sprite.Location);

            effect.Apply(1.0f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);
        }

        [Test]
        public void TestMoveEffect_Reset() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);

            IPointLocator pl1 = Locators.At(100, 200);

            IEffect effect = new MoveEffect(pl1);
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(1.0f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);
            effect.Reset();
            Assert.AreEqual(new Point(10, 20), sprite.Location);
        }

        [Test]
        public void TestGotoEffect() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);

            IPointLocator pl1 = Locators.At(100, 200);

            IEffect effect = new GotoEffect(pl1);
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);

            effect.Apply(0.5f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);

            effect.Apply(1.0f);
            Assert.AreEqual(new Point(100, 200), sprite.Location);
        }

        [Test]
        public void TestFadeEffect() {
            Sprite sprite = new Sprite();
            sprite.Opacity = 1.0f;

            IEffect effect = new FadeEffect(0.25f, 0.75f);
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(0.25f, sprite.Opacity);

            effect.Apply(0.5f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            effect.Apply(1.0f);
            Assert.AreEqual(0.75f, sprite.Opacity);
        }

        [Test]
        public void TestFadeEffect_Reset() {
            Sprite sprite = new Sprite();
            sprite.Opacity = 1.5f;

            IEffect effect = new FadeEffect(0.25f, 0.75f);
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(1.0f);
            Assert.AreEqual(0.75f, sprite.Opacity);
            effect.Reset();
            Assert.AreEqual(1.5f, sprite.Opacity);
        }

        [Test]
        public void TestScaleEffect() {
            Sprite sprite = new Sprite();
            sprite.Scale = 1.0f;

            IEffect effect = new ScaleEffect(0.0f, 6.0f);
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(0.0f, sprite.Scale);

            effect.Apply(0.5f);
            Assert.AreEqual(3.0f, sprite.Scale);

            effect.Apply(1.0f);
            Assert.AreEqual(6.0f, sprite.Scale);
        }

        [Test]
        public void TestScaleEffect_Reset() {
            Sprite sprite = new Sprite();
            sprite.Scale = 1.5f;

            IEffect effect = new ScaleEffect(0.0f, 6.0f);
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(1.0f);
            Assert.AreEqual(6.0f, sprite.Scale);
            effect.Reset();
            Assert.AreEqual(1.5f, sprite.Scale);
        }

        [Test]
        public void TestRectangleWalkEffect() {
            Sprite sprite = new Sprite();
            sprite.Location = new Point(10, 20);
            sprite.Size = new Size(10, 20);

            Rectangle r = new Rectangle(100, 200, 300, 400);
            IEffect effect = new RectangleWalkEffect(new FixedRectangleLocator(r));
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(new Point(95, 190), sprite.Location);

            effect.Apply(0.5f);
            Assert.AreEqual(new Point(395, 590), sprite.Location);

            effect.Apply(1.0f);
            Assert.AreEqual(new Point(95, 190), sprite.Location);
        }

        [Test]
        public void TestRectangleWalkEffect_WithStartPoint() {
            Sprite sprite = new Sprite();
            sprite.Location = new Point(10, 20);
            sprite.Size = new Size(10, 20);

            Rectangle r = new Rectangle(0, 0, 200, 300);
            IEffect effect = new RectangleWalkEffect(new FixedRectangleLocator(r), null, 
                WalkDirection.Clockwise, new FixedPointLocator(new Point(200, 300)));
            effect.Sprite = sprite;
            effect.Start();

            effect.Apply(0.0f);
            Assert.AreEqual(new Point(195, 290), sprite.Location);

            effect.Apply(0.5f);
            Assert.AreEqual(new Point(-5, -10), sprite.Location);
        }

        [Test]
        public void TestBlinkEffect() {
            BlinkEffect effect = new BlinkEffect(1, 2, 3, 4);
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;

            // Giving the effect 1, 2, 3, 4 means that the periods are
            // exactly corresponding to 10%.

            // 0.0-0.1 fading in
            effect.Apply(0.0f);
            Assert.AreEqual(0, sprite.Opacity);
            effect.Apply(0.05f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            // 0.1-0.3 visible
            effect.Apply(0.2f);
            Assert.AreEqual(1.0f, sprite.Opacity);
            effect.Apply(0.3f);
            Assert.AreEqual(1.0f, sprite.Opacity);

            // 0.3-0.6 fading out
            effect.Apply(0.3f);
            Assert.AreEqual(1.0f, sprite.Opacity);
            effect.Apply(0.45f);
            Assert.AreEqual(0.5f, sprite.Opacity);
            effect.Apply(0.6f);
            Assert.AreEqual(0.0f, sprite.Opacity);

            // 0.6-1.0 invisible
            effect.Apply(0.6f);
            Assert.AreEqual(0.0f, sprite.Opacity);
            effect.Apply(0.8f);
            Assert.AreEqual(0.0f, sprite.Opacity);
            effect.Apply(1.0f);
            Assert.AreEqual(0.0f, sprite.Opacity);
        }

        [Test]
        public void TestBlinkEffect_AllFadeIn() {
            BlinkEffect effect = new BlinkEffect(1, 0, 0, 0);
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;

            effect.Apply(0.0f);
            Assert.AreEqual(0, sprite.Opacity);

            effect.Apply(0.25f);
            Assert.AreEqual(0.25f, sprite.Opacity);

            effect.Apply(0.5f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            effect.Apply(0.75f);
            Assert.AreEqual(0.75f, sprite.Opacity);

            effect.Apply(1.0f);
            Assert.AreEqual(1.0, sprite.Opacity);
        }

        [Test]
        public void TestBlinkEffect_AllFadeOut() {
            BlinkEffect effect = new BlinkEffect(0, 0, 1, 0);
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;

            effect.Apply(0.0f);
            Assert.AreEqual(1.0f, sprite.Opacity);

            effect.Apply(0.25f);
            Assert.AreEqual(0.75f, sprite.Opacity);

            effect.Apply(0.5f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            effect.Apply(0.75f);
            Assert.AreEqual(0.25f, sprite.Opacity);

            effect.Apply(1.0f);
            Assert.AreEqual(0.0f, sprite.Opacity);
        }

        [Test]
        public void TestRepeater() {
            MockEffect effect = new MockEffect();
            Repeater repeater = new Repeater(2, effect);

            repeater.Apply(0.1f);
            Assert.AreEqual(0.2f, effect.FractionDone);
            repeater.Apply(0.2f);
            Assert.AreEqual(0.4f, effect.FractionDone);

            repeater.Apply(0.6f);
            Assert.AreEqual(0.2f, effect.FractionDone);
            repeater.Apply(0.7f);
            Assert.AreEqual(0.4f, effect.FractionDone);
        }

        [Test]
        public void TestRepeater_WithSprite() {
            IEffect effect = new FadeEffect(0.2f, 0.8f);
            Repeater repeater = new Repeater(2, effect);
            Sprite sprite = new Sprite();
            repeater.Sprite = sprite;
            repeater.Start();

            repeater.Apply(0.0f);
            Assert.AreEqual(0.2f, sprite.Opacity);

            repeater.Apply(0.25f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            repeater.Apply(0.5f);
            Assert.AreEqual(0.2f, sprite.Opacity);

            repeater.Apply(0.75f);
            Assert.AreEqual(0.5f, sprite.Opacity);

            repeater.Apply(1.0f);
            Assert.AreEqual(0.8f, sprite.Opacity);
        }

        [Test]
        public void TestGenericEffect_float() {
            IEffect effect = new GenericEffect<float>("Opacity", 0.2f, 0.8f);
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(0.0f);
            Assert.AreEqual(0.2f, sprite.Opacity);
            effect.Apply(0.5f);
            Assert.AreEqual(0.5f, sprite.Opacity);
            effect.Apply(1.0f);
            Assert.AreEqual(0.8f, sprite.Opacity);
        }

        [Test]
        public void TestGenericEffect_Point() {
            IEffect effect = new GenericEffect<Point>("Location", new Point(10, 20), new Point(30, 40));
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(0.0f);
            Assert.AreEqual(new Point(10, 20), sprite.Location);
            effect.Apply(0.5f);
            Assert.AreEqual(new Point(20, 30), sprite.Location);
            effect.Apply(1.0f);
            Assert.AreEqual(new Point(30, 40), sprite.Location);
        }

        [Test]
        public void TestGenericEffect_Rectangle() {
            IEffect effect = new GenericEffect<Rectangle>("Bounds", new Rectangle(10, 20, 30, 40), new Rectangle(100, 200, 300, 400));
            Sprite sprite = new Sprite();
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(0.0f);
            Assert.AreEqual(new Rectangle(10, 20, 30, 40), sprite.Bounds);
            effect.Apply(0.5f);
            Assert.AreEqual(new Rectangle(55, 110, 165, 220), sprite.Bounds);
            effect.Apply(1.0f);
            Assert.AreEqual(new Rectangle(100, 200, 300, 400), sprite.Bounds);
        }

        [Test]
        public void TestGenericEffect_Color() {
            IEffect effect = new GenericEffect<Color>("ForeColor", Color.FromArgb(1, 2, 3, 4), Color.FromArgb(100, 200, 30, 40));
            TextSprite sprite = new TextSprite();
            effect.Sprite = sprite;
            effect.Start();
            effect.Apply(0.0f);

            Assert.AreEqual(Color.FromArgb(1, 2, 3, 4), sprite.ForeColor);
            effect.Apply(0.5f);
            Assert.AreEqual(Color.FromArgb(50, 50, 27, 59), sprite.ForeColor);
            effect.Apply(1.0f);
            Assert.AreEqual(Color.FromArgb(100, 200, 30, 40), sprite.ForeColor);
        }

        public class MockEffect : IEffect
        {
            public float FractionDone;

            public ISprite Sprite { get; set; }

            public void Start() {
                throw new NotImplementedException();
            }

            public void Apply(float fractionDone) {
                this.FractionDone = fractionDone;
            }

            public void Stop() {
                throw new NotImplementedException();
            }

            public void Reset() {
                throw new NotImplementedException();
            }
        }
    }
}