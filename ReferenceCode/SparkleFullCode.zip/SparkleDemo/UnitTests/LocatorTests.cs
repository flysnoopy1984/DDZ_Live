﻿using System;
using System.Drawing;
using System.Diagnostics;

using NUnit.Framework;

using BrightIdeasSoftware;

namespace BrightIdeasSoftware.AnimationTests
{
    [TestFixture]
    public class LocatorTests
    {
        [Test, Sequential]
        public void TestSpriteCorner_TopLeft(
            [Values(Corner.TopLeft, Corner.MiddleCenter,Corner.BottomRight)]Corner corner,
            [Values(10, 25, 40)]int x,
            [Values(20, 40, 60)]int y
            ) {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);
            IPointLocator pl = Locators.SpriteBoundsPoint(corner);
            pl.Sprite = sprite;
            Assert.AreEqual(new Point(x, y), pl.GetPoint());
        }


        [Test, Sequential]
        public void TestSpriteAligned(
            [Values(Corner.TopLeft, Corner.TopRight, Corner.MiddleCenter, Corner.BottomRight)]Corner corner,
            [Values(100, 370, 235, 370)]int x,
            [Values(200, 200, 380, 560)]int y) {
            Animation animation = new Animation();
            animation.Bounds = new Rectangle(100, 200, 300, 400);
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);
            sprite.Animation = animation;

            IPointLocator pl = Locators.SpriteAligned(corner);
            pl.Sprite = sprite;
            Assert.AreEqual(new Point(x, y), pl.GetPoint());
        }
    }
}
