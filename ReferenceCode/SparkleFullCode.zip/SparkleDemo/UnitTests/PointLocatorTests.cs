﻿using System;
using System.Drawing;
using System.Diagnostics;

using NUnit.Framework;

using BrightIdeasSoftware;

namespace BrightIdeasSoftware.AnimationTests
{
    [TestFixture]
    public class PointLocatorTests
    {
        [Test]
        public void TestFixedPointLocator() {
            Point pt = new Point(10, 12);
            FixedPointLocator pl = new FixedPointLocator(pt);

            Assert.AreEqual(pt, pl.GetPoint());
        }

        [Test]
        public void TestFixedPointLocator_WithOffset() {
            Point pt = new Point(10, 12);
            FixedPointLocator pl = new FixedPointLocator(pt);
            pl.Offset = new Point(100, 100);

            Assert.AreEqual(new Point(pt.X+100, pt.Y+100), pl.GetPoint());
        }

        [Test]
        public void TestPointOnRectangleLocator_Corners() {
            Rectangle r = new Rectangle(10, 20, 30, 40);
            IRectangleLocator rl = new FixedRectangleLocator(r);

            PointOnRectangleLocator pl = new PointOnRectangleLocator(rl, Corner.TopLeft);
            Assert.AreEqual(r.Location, pl.GetPoint());

            pl = new PointOnRectangleLocator(rl, Corner.BottomRight);
            Assert.AreEqual(new Point(r.Right, r.Bottom), pl.GetPoint());

            pl = new PointOnRectangleLocator(rl, Corner.MiddleRight);
            Assert.AreEqual(new Point(r.Right, r.Top + (r.Height / 2)), pl.GetPoint());
        }

        [Test]
        public void TestPointOnRectangleLocator_Proportions() {
            Rectangle r = new Rectangle(10, 20, 30, 40);
            IRectangleLocator rl = new FixedRectangleLocator(r);

            PointOnRectangleLocator pl = new PointOnRectangleLocator(rl, 0.25f, 0.75f);
            Point pt = new Point(r.Left + (int)(r.Width * 0.25f), r.Top + (int)(r.Height * 0.75f));
            Assert.AreEqual(pt, pl.GetPoint());
        }

        [Test]
        public void TestPointOnRectangleLocator_WithOffset() {
            Rectangle r = new Rectangle(10, 20, 30, 40);
            IRectangleLocator rl = new FixedRectangleLocator(r);

            PointOnRectangleLocator pl = new PointOnRectangleLocator(rl, Corner.TopLeft, new Point(-10, -20));
            Assert.AreEqual(new Point(0, 0), pl.GetPoint());
        }

        [Test]
        public void TestDifferenceLocator() {
            IPointLocator fpl1 = new FixedPointLocator(new Point(100, 200));
            IPointLocator fpl2 = new FixedPointLocator(new Point(50, 100));

            DifferenceLocator pl = new DifferenceLocator(fpl1, fpl2);
            Assert.AreEqual(new Point(50, 100), pl.GetPoint());
        }

        [Test]
        public void TestDifferenceLocator_WithOffset() {
            IPointLocator fpl1 = new FixedPointLocator(new Point(100, 200));
            IPointLocator fpl2 = new FixedPointLocator(new Point(50, 100));

            DifferenceLocator pl = new DifferenceLocator(fpl1, fpl2, new Point(-50, -100));
            Assert.AreEqual(new Point(0, 0), pl.GetPoint());
        }

        [Test]
        public void TestNestedLocators_Propagation() {
            // Check that changing the sprite on a top level locator affects the sublocators too

            SpriteBoundsLocator sbl1 = new SpriteBoundsLocator();
            SpriteBoundsLocator sbl2 = new SpriteBoundsLocator(10, 10);

            PointOnRectangleLocator prl1 = new PointOnRectangleLocator(sbl1, Corner.TopLeft);
            PointOnRectangleLocator prl2 = new PointOnRectangleLocator(sbl2, Corner.TopLeft);

            Sprite sprite = new Sprite();

            DifferenceLocator dl = new DifferenceLocator(prl1, prl2);
            dl.Sprite = sprite;

            Assert.AreEqual(prl1.Sprite, sprite);
            Assert.AreEqual(prl2.Sprite, sprite);
            Assert.AreEqual(sbl1.Sprite, sprite);
            Assert.AreEqual(sbl2.Sprite, sprite);
        }

        [Test]
        public void TestNestedLocators_Calculations() {

            SpriteBoundsLocator sbl1 = new SpriteBoundsLocator();
            SpriteBoundsLocator sbl2 = new SpriteBoundsLocator(10, 10);

            PointOnRectangleLocator prl1 = new PointOnRectangleLocator(sbl1, Corner.TopLeft);
            PointOnRectangleLocator prl2 = new PointOnRectangleLocator(sbl2, Corner.TopLeft);

            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(1, 2, 3, 4);

            DifferenceLocator dl = new DifferenceLocator(prl1, prl2);
            dl.Sprite = sprite;

            Assert.AreEqual(new Point(10, 10), dl.GetPoint());
        }

        [Test]
        public void TestAlignedSpriteLocators() {
            Animation animation = new Animation();
            animation.Bounds = new Rectangle(100, 200, 300, 400);
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);
            sprite.Animation = animation;

            CheckAlignedSpriteCalculatedPoint(sprite, Corner.TopLeft, new Point(100, 200));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.TopCenter, new Point(235, 200));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.TopRight, new Point(370, 200));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.MiddleLeft, new Point(100, 380));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.MiddleCenter, new Point(235, 380));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.MiddleRight, new Point(370, 380));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.BottomLeft, new Point(100, 560));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.BottomCenter, new Point(235, 560));
            CheckAlignedSpriteCalculatedPoint(sprite, Corner.BottomRight, new Point(370, 560));
        }

        private void CheckAlignedSpriteCalculatedPoint(Sprite sprite, Corner corner, Point pt) {
            AlignedSpriteLocator asl = new AlignedSpriteLocator(
                new PointOnRectangleLocator(new AnimationBoundsLocator(), corner),
                new PointOnRectangleLocator(new SpriteBoundsLocator(), corner));
            asl.Sprite = sprite;

            Assert.AreEqual(pt, asl.GetPoint());
        }

        [Test]
        public void TestAlignedSpriteLocators_WithOffset() {
            Animation animation = new Animation();
            animation.Bounds = new Rectangle(100, 200, 300, 400);
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);
            sprite.Animation = animation;

            AlignedSpriteLocator asl = new AlignedSpriteLocator(
                new PointOnRectangleLocator(new AnimationBoundsLocator(), Corner.MiddleCenter),
                new PointOnRectangleLocator(new SpriteBoundsLocator(), Corner.MiddleCenter),
                new Point(-35, -80));
            asl.Sprite = sprite;

            Assert.AreEqual(new Point(200, 300), asl.GetPoint());
        }

        [Test]
        public void TestRectangleWalkLocators() {
            // Rectangle has a perimeter of 1000 making it easy to calculate percentaged walked
            IRectangleLocator rl = Locators.At(0, 0, 200, 300);
            

            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.0f, new Point(0, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.1f, new Point(100, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.2f, new Point(200, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.3f, new Point(200, 100));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.4f, new Point(200, 200));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.5f, new Point(200, 300));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.6f, new Point(100, 300));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.7f, new Point(1, 300));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.8f, new Point(0, 200));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.9f, new Point(0, 101));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 0), 1.0f, new Point(0, 0));
        }

        [Test]
        public void TestRectangleWalkLocators_WithStartPoint() {
            // Rectangle has a perimeter of 1000 making it easy to calculate percentaged walked
            IRectangleLocator rl = Locators.At(0, 0, 200, 300);

            // Start in segment 2
            CheckRectangleWalkCalculatedPoint(rl, new Point(50, 0), 0.0f, new Point(50, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(50, 0), 0.1f, new Point(150, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(50, 0), 0.9f, new Point(0, 51));

            // Start in segment 3
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 50), 0.0f, new Point(0, 50));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 50), 0.1f, new Point(50, 0));
            CheckRectangleWalkCalculatedPoint(rl, new Point(0, 50), 0.9f, new Point(0, 151));
        }

        private void CheckRectangleWalkCalculatedPoint(IRectangleLocator rl, Point start, float progress, Point pt) {
            RectangleWalker walker = new RectangleWalker();
            walker.RectangleLocator = rl;
            walker.StartPointLocator = Locators.At(start);
            walker.WalkProgress = progress;
            walker.Direction = WalkDirection.Clockwise;

            Assert.AreEqual(pt, walker.GetPoint());
        }

        [Test]
        public void TestRectangleWalkLocators_Anticlockwise() {
            // Rectangle has a perimeter of 1000 making it easy to calculate percentaged walked
            IRectangleLocator rl = Locators.At(0, 0, 200, 300);

            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.0f, new Point(0, 0));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.1f, new Point(0, 100));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.2f, new Point(0, 200));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.3f, new Point(0, 300));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.4f, new Point(100, 300));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.5f, new Point(200, 300));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.6f, new Point(200, 200));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.7f, new Point(200, 101));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.8f, new Point(200, 0));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 0.9f, new Point(101, 0));
            CheckAnticlockwiseRectangleWalkCalculatedPoint(rl, new Point(0, 0), 1.0f, new Point(0, 0));
        }

        private void CheckAnticlockwiseRectangleWalkCalculatedPoint(IRectangleLocator rl, Point start, float progress, Point pt) {
            RectangleWalker walker = new RectangleWalker();
            walker.RectangleLocator = rl;
            walker.StartPointLocator = Locators.At(start);
            walker.WalkProgress = progress;
            walker.Direction = WalkDirection.Anticlockwise;

            Assert.AreEqual(pt, walker.GetPoint());
        }

        [Test]
        public void TestRectangleWalkLocators_StartPoint() {
            IRectangleLocator rl = Locators.At(0, 0, 200, 300);
            RectangleWalker walker = new RectangleWalker(rl, WalkDirection.Clockwise, Locators.At(200, 300));
            walker.WalkProgress = 0.0f;
            Assert.AreEqual(new Point(200, 300), walker.GetPoint());

            walker.WalkProgress = 0.5f;
            Assert.AreEqual(new Point(0, 0), walker.GetPoint());
        }

        [Test]
        public void TestEndPointCalculation() {
            EndPointTester ept = new EndPointTester();

            // test all quadrants
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(-10, -10), new Point(10, 10), 15));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(10, 10), new Point(-10, -10), 15));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(-10, 10), new Point(10, -10), 15));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(10, -10), new Point(-10, 10), 15));

            // test other angles
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(-3, -4), new Point(3, 4), 5));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(3, 4), new Point(-3, -4), 5));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(-3, 4), new Point(3, -4), 5));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(3, -4), new Point(-3, 4), 5));

            // test vertical and horizontal
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(10, 0), new Point(-10, 0), 10));
            Assert.AreEqual(new Point(0, 0), ept.TestCalculateEndPoint(new Point(0, 10), new Point(0, -10), 10));
        }

        class EndPointTester : RectangleWalker
        {
            public Point TestCalculateEndPoint(Point pt1, Point pt2, int distance) {
                return this.CalculateEndPoint(pt1, pt2, distance);
            }
        }

        [Test]
        public void TestPointWalker() {
            Point[] points = new Point[] { new Point(-10, -5), new Point(0, -5), new Point(0, 0), new Point(3, 4), new Point(13, 4) };
            PointWalker walker = new PointWalker(points);

            walker.WalkProgress = 0.0f;
            Assert.AreEqual(points[0], walker.GetPoint());

            walker.WalkProgress = 0.25f;
            Assert.AreEqual(new Point(-3, -5), walker.GetPoint());

            walker.WalkProgress = 0.5f;
            Assert.AreEqual(points[2], walker.GetPoint());

            walker.WalkProgress = 0.75f;
            Assert.AreEqual(new Point(6, 4), walker.GetPoint());

            walker.WalkProgress = 1.0f;
            Assert.AreEqual(points[points.Length-1], walker.GetPoint());
        }

        [Test]
        public void TestPointWalker_WithOffset() {
            Point[] points = new Point[] { new Point(-10, -5), new Point(0, -5), new Point(0, 0), new Point(3, 4), new Point(13, 4) };
            PointWalker walker = new PointWalker(points, new Point(5, 5));

            walker.WalkProgress = 0.5f;
            Assert.AreEqual(new Point(5, 5), walker.GetPoint());
        }
    }
}
