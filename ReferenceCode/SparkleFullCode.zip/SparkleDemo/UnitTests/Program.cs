﻿using System;

namespace BrightIdeasSoftware.AnimationTests
{
    class Program
    {
        static void Main(string[] args) {
            PointLocatorTests tests = new PointLocatorTests();
            tests.TestFixedPointLocator();
            tests.TestFixedPointLocator_WithOffset();
            tests.TestPointOnRectangleLocator_Corners();
            tests.TestPointOnRectangleLocator_Proportions();
            tests.TestPointOnRectangleLocator_WithOffset();
            tests.TestDifferenceLocator();
            tests.TestDifferenceLocator_WithOffset();
            tests.TestRectangleWalkLocators();
            tests.TestRectangleWalkLocators_WithStartPoint();
            tests.TestRectangleWalkLocators_Anticlockwise();
            tests.TestEndPointCalculation();
            tests.TestPointWalker();

            RectangleLocatorTests rectTests = new RectangleLocatorTests();
            rectTests.TestFixedRectangleLocator();
            rectTests.TestFixedRectangleLocator_WithExpansion();
            rectTests.TestRectangleFromCornersLocator();

            EffectTests effectTests = new EffectTests();
            effectTests.Setup();
            effectTests.TestMoveEffect();
            effectTests.TestRectangleWalkEffect();
            effectTests.TestRectangleWalkEffect_WithStartPoint();

            effectTests.TestBlinkEffect();
            effectTests.TestRepeater_WithSprite();

            effectTests.TestGenericEffect_Color();

            Console.WriteLine("all done");
            Console.ReadKey();
        }
    }
}
