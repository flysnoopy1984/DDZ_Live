﻿using System;
using System.Drawing;
using System.Diagnostics;

using NUnit.Framework;
using NUnit.Mocks;

using BrightIdeasSoftware;

namespace BrightIdeasSoftware.AnimationTests
{
    [TestFixture]
    public class RectangleLocatorTests
    {
        [Test]
        public void TestFixedRectangleLocator() {
            Rectangle r = new Rectangle(10, 20, 30, 40);
            FixedRectangleLocator rl = new FixedRectangleLocator(r);

            Assert.AreEqual(r, rl.GetRectangle());
        }

        [Test]
        public void TestFixedRectangleLocator_WithExpansion() {
            Rectangle r = new Rectangle(10, 20, 30, 40);
            FixedRectangleLocator rl = new FixedRectangleLocator(r);
            rl.Expansion = new Point(10, 100);
            Assert.AreEqual(new Rectangle(r.X - 10, r.Top - 100, r.Width + 20, r.Height + 200), rl.GetRectangle());
        }

        [Test]
        public void TestRectangleFromCornersLocator() {
            IPointLocator pl1 = new FixedPointLocator(new Point(10, 20));
            IPointLocator pl2 = new FixedPointLocator(new Point(100, 200));

            RectangleFromCornersLocator rl = new RectangleFromCornersLocator(pl1, pl2);
            Assert.AreEqual(new Rectangle(10, 20, 90, 180), rl.GetRectangle());
        }

        [Test]
        public void TestRectangleFromCornersLocator_WithExpansion() {
            IPointLocator pl1 = new FixedPointLocator(new Point(10, 20));
            IPointLocator pl2 = new FixedPointLocator(new Point(100, 200));

            RectangleFromCornersLocator rl = new RectangleFromCornersLocator(pl1, pl2);
            rl.Expansion = new Point(10, 20);
            Assert.AreEqual(new Rectangle(0, 0, 110, 220), rl.GetRectangle());
        }

        [Test]
        public void TestSpriteBoundsLocator() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(1, 2, 3, 4);
            SpriteBoundsLocator rl = new SpriteBoundsLocator(sprite);
            Assert.AreEqual(new Rectangle(1, 2, 3, 4), rl.GetRectangle());
        }

        [Test]
        public void TestSpriteBoundsLocator_WithExpansion() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);
            SpriteBoundsLocator rl = new SpriteBoundsLocator(1, 1);
            rl.Sprite = sprite;
            Assert.AreEqual(new Rectangle(9, 19, 32, 42), rl.GetRectangle());
        }

        [Test]
        public void TestAnimationBoundsLocator() {
            Animation animation = new Animation();
            animation.Bounds = new Rectangle(100, 200, 300, 400);
            Sprite sprite = new Sprite();
            sprite.Animation = animation;
            AnimationBoundsLocator rl = new AnimationBoundsLocator();
            rl.Sprite = sprite;
            Assert.AreEqual(new Rectangle(100, 200, 300, 400), rl.GetRectangle());
        }

        [Test]
        public void TestAnimationBoundsLocator_WithExpansion() {
            Animation animation = new Animation();
            animation.Bounds = new Rectangle(100, 200, 300, 400);
            Sprite sprite = new Sprite();
            sprite.Animation = animation;
            AnimationBoundsLocator rl = new AnimationBoundsLocator(100, 200);
            rl.Sprite = sprite;
            Assert.AreEqual(new Rectangle(0, 0, 500, 800), rl.GetRectangle());
        }
    }
}
