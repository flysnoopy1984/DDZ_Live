﻿using System;
using System.Drawing;
using System.Diagnostics;

using NUnit.Framework;
using NUnit.Mocks;

using BrightIdeasSoftware;

namespace BrightIdeasSoftware.AnimationTests
{
    [TestFixture]
    public class SpriteTests
    {
        [Test]
        public void TestTick_Stops() {
            Sprite sprite = new Sprite();
            MockEffect effect = new MockEffect();

            Assert.IsFalse(sprite.Tick(1));
            sprite.Add(100, effect);
            Assert.IsTrue(sprite.Tick(1));
            Assert.IsFalse(sprite.Tick(101));
        }

        public void TestTick_StartCalled() {
            Sprite sprite = new Sprite();
            MockEffect effect = new MockEffect();

            sprite.Add(100, effect);
            sprite.Tick(1);
            Assert.AreEqual(0, effect.StartCalled);
            sprite.Tick(101);
            Assert.AreEqual(1, effect.StartCalled);
        }

        public void TestTick_ApplyCalled_ZeroDurationEffect() {
            Sprite sprite = new Sprite();
            MockEffect effect = new MockEffect();

            sprite.Add(100, effect);
            sprite.Tick(1);
            Assert.AreEqual(0, effect.ApplyCalled);
            sprite.Tick(101);
            Assert.AreEqual(1, effect.ApplyCalled);
            Assert.AreEqual(1.0f, effect.ApplyFraction);
        }

        public void TestTick_ApplyCalled_DurationEffect() {
            Sprite sprite = new Sprite();
            MockEffect effect = new MockEffect();

            sprite.Add(1000, 2000, effect);
            sprite.Tick(0);
            Assert.AreEqual(0, effect.ApplyCalled);
            sprite.Tick(1000);
            Assert.AreEqual(1, effect.ApplyCalled);
            Assert.AreEqual(0.0f, effect.ApplyFraction);
            sprite.Tick(2000);
            Assert.AreEqual(2, effect.ApplyCalled);
            Assert.AreEqual(0.5f, effect.ApplyFraction);
            sprite.Tick(3001);
            Assert.AreEqual(3, effect.ApplyCalled);
            Assert.AreEqual(1.0f, effect.ApplyFraction);
        }

        [Test]
        public void TestTick_StopCalled() {
            Sprite sprite = new Sprite();
            MockEffect effect = new MockEffect();

            sprite.Add(1000, 2000, effect);
            sprite.Tick(0);
            Assert.AreEqual(0, effect.StopCalled);
            sprite.Tick(1000);
            Assert.AreEqual(0, effect.StopCalled);
            sprite.Tick(4000);
            Assert.AreEqual(1, effect.StopCalled);
        }

        [Test]
        public void TestReset() {
            Sprite sprite = new Sprite();
            MockEffectReseter effect = new MockEffectReseter(2);
            sprite.Location = new Point(1, 1);

            sprite.Add(1000, 2000, effect);
            sprite.Reset();

            Assert.AreEqual(2, sprite.Location.X);
        }

        [Test]
        public void TestReset_Unwind() {
            Sprite sprite = new Sprite();
            MockEffectReseter effect1 = new MockEffectReseter(1);
            MockEffectReseter effect2 = new MockEffectReseter(2);
            sprite.Location = new Point(0, 0);

            // Check that effects are unwound by start time, not by order added or end time
            sprite.Add(1000, 2000, effect1);
            sprite.Add(0, 4000, effect2);
            sprite.Reset();

            Assert.AreEqual(2, sprite.Location.X);
        }

        [Test]
        public void TestAnimationBounds() {
            Sprite sprite = new Sprite();
            Animation animation = new Animation();
            Rectangle r = new Rectangle(10, 20, 30, 40);
            animation.Bounds = r;
            sprite.Animation = animation;

            Assert.AreEqual(r, sprite.OuterBounds);
        }

        [Test]
        public void TestReferenceBounds_Default() {
            Sprite sprite = new Sprite();
            Animation animation = new Animation();
            Rectangle r = new Rectangle(10, 20, 30, 40);
            animation.Bounds = r;
            sprite.Animation = animation;

            Assert.AreEqual(r, sprite.ReferenceBounds);
        }

        [Test]
        public void TestReferenceBounds_Explicit() {
            Sprite sprite = new Sprite();
            Animation animation = new Animation();
            Rectangle r = new Rectangle(10, 20, 30, 40);
            animation.Bounds = r;
            sprite.Animation = animation;
            sprite.ReferenceBoundsLocator = Locators.At(100, 200, 300, 400);

            Assert.AreEqual(new Rectangle(100, 200, 300, 400), sprite.ReferenceBounds);
        }

        [Test]
        public void TestFixedLocation() {
            Sprite sprite = new Sprite();
            sprite.Location = new Point(10, 10);
            Point pt = new Point(20, 20);
            sprite.FixedLocation = Locators.At(pt);

            Assert.AreNotEqual(pt, sprite.Location);
            sprite.Tick(1);
            Assert.AreEqual(pt, sprite.Location);
        }

        [Test]
        public void TestFixedBounds() {
            Sprite sprite = new Sprite();
            sprite.Bounds = new Rectangle(10, 20, 30, 40);

            Rectangle r = new Rectangle(100, 200, 300, 400);
            sprite.FixedBounds = Locators.At(r);

            Assert.AreNotEqual(r, sprite.Bounds);
            sprite.Tick(1);
            Assert.AreEqual(r, sprite.Bounds);
        }

        protected class MockEffect : IEffect
        {
            #region IEffect Members

            public ISprite Sprite { get; set; }

            public void Start() {
                this.StartCalled++;
            }

            public void Apply(float fractionDone) {
                this.ApplyCalled++;
                this.ApplyFraction = fractionDone;
            }

            public void Stop() {
                this.StopCalled++;
            }

            public void Reset() {
                this.ResetCalled++;
            }

            #endregion

            public int StartCalled;
            public int ApplyCalled;
            public float ApplyFraction;
            public int StopCalled;
            public int ResetCalled;
        }

        protected class MockEffectReseter : IEffect
        {
            public MockEffectReseter(int x) {
                locationX = x;
            }
            int locationX;

            public ISprite Sprite { get; set; }

            public void Start() { }
            public void Apply(float fractionDone) { }
            public void Stop() { }

            public void Reset() { this.Sprite.Location = new Point(locationX, 0); }
        }
    }
}