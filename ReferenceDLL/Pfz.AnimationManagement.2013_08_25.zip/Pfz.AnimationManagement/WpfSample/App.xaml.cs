﻿using System.Windows;

namespace WpfSample
{
    /// <summary>
    /// Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
